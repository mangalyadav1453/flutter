// ignore_for_file: non_constant_identifier_names
//routes file code
class MyRoutes {
  static String LoginRoute = "/Login";
  static String HomeRoute = "/Home";
}
