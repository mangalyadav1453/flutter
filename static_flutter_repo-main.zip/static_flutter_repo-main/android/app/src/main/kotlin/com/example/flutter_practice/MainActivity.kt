package com.example.flutter_practice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
